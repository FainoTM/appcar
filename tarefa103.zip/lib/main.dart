import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with TickerProviderStateMixin {
  late TabController _tabController;
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          leading: const Icon(
            Icons.menu,
            size: 30,
            color: Colors.black87,
          ),
          title: const Text(
            'InfoCar App',
            style: TextStyle(color: Colors.black87),
          ),
          actions: const [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 20, 0),
              child: Icon(
                Icons.search,
                color: Colors.black87,
              ),
            )
          ],
          backgroundColor: const Color.fromRGBO(234, 234, 234, 1.0),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 30, 0, 30),
                child: Center(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color.fromRGBO(234, 234, 234, 1.0),
                    ),
                    width: 330,
                    height: 218,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              const Text(
                                'Marcas',
                                style: TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              const Spacer(), // Cria um espaço flexível
                              GestureDetector(
                                onTap: () {},
                                child: const Text(
                                  'Ver todas',
                                  style: TextStyle(
                                    color: Color.fromARGB(221, 1, 119, 255),
                                    fontSize: 15,
                                    decoration: TextDecoration
                                        .underline, // Adicione sublinhado
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: logos(),
                          ),
                          Row(
                            children: logos(),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 30),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: const Color.fromRGBO(195, 194, 254, 1),
                  ),
                  width: 330,
                  height: 126,
                  child: Row(
                    children: [
                      const Padding(
                        padding: EdgeInsets.fromLTRB(10, 30, 40, 0),
                        child: Column(
                          children: [
                            Text(
                              'Carros disponíveis',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 26,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.fromLTRB(0, 10, 40, 0),
                              child: Text(
                                'Confira a lista completa',
                                style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child: GestureDetector(
                          onTap: () {
                            // Adicione ação ao pressionar o botão de seta aqui.
                          },
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              color: Colors.white,
                              shape: BoxShape.rectangle,
                            ),
                            child: const Icon(
                              Icons.arrow_forward,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color.fromRGBO(234, 234, 234, 1.0),
                ),
                width: 330,
                height: 206,
                child: Column(
                  children: [
                    const Padding(
                      padding: EdgeInsets.fromLTRB(0, 20, 110, 0),
                      child: Text(
                        'Mais acessados',
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 28,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: listcarros(),
                      ),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 30,
              )
            ],
          ),
        ),
        bottomNavigationBar: TabBar(
          controller: _tabController,
          indicator: const BoxDecoration(
              color: Color.fromRGBO(114, 110, 116, 0.2),
              border:
                  Border(bottom: BorderSide(color: Colors.purple, width: 3))),
          tabs: const <Widget>[
            Tab(
              icon: Icon(
                Icons.directions_car_filled,
                color: Colors.black87,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.favorite_outline,
                color: Colors.black87,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.person_2_outlined,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> logos() {
    List<Widget> logo = [];
    for (var i = 0; i < 4; i++) {
      Widget contlogo = Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 0, 0),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white70, borderRadius: BorderRadius.circular(20)),
          width: 65,
          height: 70,
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Column(
              children: [
                Image.asset('images/acura_logo.png', width: 40, height: 40),
                const Text(
                  'Acura',
                )
              ],
            ),
          ),
        ),
      );
      logo.add(contlogo);
    }
    return logo;
  }

  List<Widget> listcarros() {
    List<Widget> carro = [];
    for (var i = 0; i < 8; i++) {
      Widget contcarro = Padding(
        padding: const EdgeInsets.fromLTRB(7, 5, 0, 0),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white70, borderRadius: BorderRadius.circular(20)),
          width: 128,
          height: 128,
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Column(
              children: [
                Image.asset('images/carro_foto.png', width: 90, height: 50),
                const Text(
                  'INTEGRA',
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(0, 7, 0, 0),
                  child: Text(
                    'Acura',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(0, 7, 0, 0),
                  child: Text('\$31,500+'),
                ),
              ],
            ),
          ),
        ),
      );
      carro.add(contcarro);
    }
    return carro;
  }
}
